/**
 * 
 */
package br.com.servicedesk;

/**
 * @author Alan Lira - arslir@gmail.com / Kleyber Dantas - kleyber.dantas@gmail
 * 
 * MBA Full Stack Web Development
 * 
 * Design de C�digo com SOLID
 * 
 * Desafio - Service Desk 
 *
 */
public class Cliente extends Pessoa implements GerenciaCliente{

	public String dataContrato;
	public String numeroContrato;
	public int tipoCliente;

	
	
	@Override
	public void salvar(Object cliente) {
		// TODO Auto-generated method stub
		
		
	}
	@Override
	public void atualizar() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void deletar() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void vizualizar() {
		// TODO Auto-generated method stub
		
	}

	
}
