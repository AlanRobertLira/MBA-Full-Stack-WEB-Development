/**
 * 
 */
package br.com.servicedesk;

/**
 * @author Alan Lira - arslir@gmail.com / Kleyber Dantas - kleyber.dantas@gmail
 * 
 * MBA Full Stack Web Development
 * 
 * Design de C�digo com SOLID
 * 
 * Desafio - Service Desk 
 *
 */
public class Pessoa {
	
	protected int id;
	protected String nome;
	protected String dataCadastro;	
	protected String dataNascimento;
	protected String endereco;
	protected String rg;
	protected String cpf;
	protected String telefone;
	protected String celular;
	protected String email;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getDataNascimento() {
		return dataNascimento;
	}
	public void setDataNascimento(String dataNascimento) {
		this.dataNascimento = dataNascimento;
	}
	public String getDataCadastro() {
		return dataCadastro;
	}
	public void setDataCadastro(String dataCadastro) {
		this.dataCadastro = dataCadastro;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getRg() {
		return rg;
	}
	public void setRg(String rg) {
		this.rg = rg;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public String getCelular() {
		return celular;
	}
	public void setCelular(String celular) {
		this.celular = celular;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

}
