/**
 * 
 */
package br.com.servicedesk;

/**
 * @author Alan Lira - arslir@gmail.com / Kleyber Dantas - kleyber.dantas@gmail
 * 
 * MBA Full Stack Web Development
 * 
 * Design de C�digo com SOLID
 * 
 * Desafio - Service Desk 
 *
 */
public class Atendente extends Pessoa implements GerenciaAtendente{
	  
		private String login;	
		private int senha;

		public String getLogin() {
			return login;
		}
		public void setLogin(String login) {
			this.login = login;
		}
		public int getSenha() {
			return senha;
		}
		public void setSenha(int senha) {
			this.senha = senha;
		}
		
		
	    public boolean autentica(String login, int senha) {
	        if (this.login == login && this.senha == senha) {
	            System.out.println("Acesso Permitido!");
	            return true;
	        } else {
	            System.out.println("Acesso Negado!");
	            return false;
	        }	


	    }
		@Override
		public void abreOs() {
			// TODO Auto-generated method stub
			
		}





}
