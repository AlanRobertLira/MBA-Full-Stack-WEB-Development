/**
 * 
 */
package br.com.servicedesk;

/**
 * @author Alan Lira
 *
 */
public class Tecnico extends Pessoa {

}
