/**
 * 
 */
package br.com.servicedesk;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * @author Alan Lira - arslir@gmail.com / Kleyber Dantas - kleyber.dantas@gmail
 * 
 * MBA Full Stack Web Development
 * 
 * Design de C�digo com SOLID
 * 
 * Desafio - Service Desk 
 *
 */
public class ServiceDesk {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int opcao = 5;
		
		do {
		System.out.println("****** Menu Service Desk ******");
		System.out.println("1 - Cadastro de Cliente");
		System.out.println("2 - Cadastro de Atendente");
		System.out.println("3 - Cadastro de T�cnico");
		System.out.println("4 - Cadastro de OS");
		System.out.println("5 - Sair");
		System.out.println("*******************************");
		System.out.println("Digite uma op��o: ");
				
		opcao = Integer.parseInt(sc.nextLine());

		switch (opcao) {
		case 1:
				
			int opCliente = 4;
			Cliente cliente = new Cliente();
			List<Cliente> listaCliente = new ArrayList<Cliente>();
	
			do {
			
			System.out.println("****** Cadastro de Cliente ******");
			System.out.println("1 - Cadastrar");
			System.out.println("2 - Vizualizar");
			System.out.println("3 - Excluir");
			System.out.println("4 - Sair");
			System.out.println("*********************************");
			System.out.println("Digite sua op��o: \n");
			
			opCliente = Integer.parseInt(sc.nextLine());
			
		
			
			switch (opCliente) {
			
			
			
			case 1:
				
	
				System.out.println("Digite o c�dgo: ");
				cliente.setId(Integer.parseInt(sc.nextLine()));
		
				System.out.println("Digite o nome: ");
				cliente.setNome(sc.nextLine());
		
				System.out.println("Digite a data de cadastro: ");
				cliente.setDataCadastro(sc.nextLine());
		
				System.out.println("Digite a data de nascimento: ");
				cliente.setDataNascimento(sc.nextLine());
		
				System.out.println("Digite o endere�o: ");
				cliente.setEndereco(sc.nextLine());
		
				System.out.println("Digite o rg: ");
				cliente.setRg(sc.nextLine());
		
				System.out.println("Digite o cpf: ");
				cliente.setCpf(sc.nextLine());
		
				System.out.println("Digite o telefone: ");
				cliente.setTelefone(sc.nextLine());
		
				System.out.println("Digite o celular: ");
				cliente.setCelular(sc.nextLine());
					
				System.out.println("Digite o e-mail: ");
				cliente.setEmail(sc.nextLine());
		
				System.out.println();
		
				listaCliente.add(cliente);								
				
			break;
			
			case 2:		
								
				if (listaCliente.isEmpty()) {
					
					System.out.println("N�o Existe");
					
					
				} else {
						
						
						System.out.println("Existe");
						
					}
					
				
				
				
				
			break;
				
			case 4:
																
			break;

			default:
				
				System.out.println("Op��o Inv�lida!");
				
			break;
			
			
			
			}
			
			} while (opCliente !=4);
			
			
			
			
		break;
		
		case 5:
		
			
		break;	

		default:
		
			System.out.println("Op��o Inv�lida!");
			
		break;
		}
		
		
		
		
		
		
		
		
	
		} while (opcao != 5);		
		sc.close();
	
	}
	
}
	