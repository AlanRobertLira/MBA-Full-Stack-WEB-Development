/**
 * 
 */
package br.com.servicedesk;

/**
 * @author Alan Lira - arslir@gmail.com / Kleyber Dantas - kleyber.dantas@gmail
 * 
 * MBA Full Stack Web Development
 * 
 * Design de C�digo com SOLID
 * 
 * Desafio - Service Desk 
 *
 */
public interface GerenciaTecnico {
	
	public void atenderchamado();

}
